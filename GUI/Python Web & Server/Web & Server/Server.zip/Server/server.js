// -------- setup dasar --------
const express   = require("express");
const http      = require("http");
const { Server } = require("socket.io");
const cors      = require("cors");

const app = express();
const server = http.createServer(app);   // <─ gunakan http.Server di-share dg Socket.IO
const io = new Server(server, { cors: { origin: "*" }});

app.use(cors());
app.use(express.json());                 // bisa terima JSON body

// ===== STATIC FILES =====
app.use(express.static(__dirname)); // supaya bisa akses HTML, CSS, dan gambar

// ── halaman statis /index.html
app.get("/", (_, res) => res.sendFile(__dirname + "/views/index.html"));

// ── endpoint untuk menerima data dari Python
app.post("/sensor", (req, res) => {
  const payload = req.body;          // { gas, smoke, pump, fan }
  io.emit("sensor", payload);        //  <-- ganti 'sensor' (bukan 'data')
  res.sendStatus(200);
});

// ── log bila ada browser yang tersambung
io.on("connection", socket => {
  console.log("browser connected");
  socket.on("disconnect", () => console.log("browser disconnected"));
});

server.listen(3000, () => console.log("Server & Socket.IO up on :3000"));
